<?php $this->extend('_templates/default-nav', array(), 'outer_box'); ?>

<?php $this->embed('_shared/form', $form); ?>
