<div class="progress-bar">
	<div class="progress" style="width: <?=$percent?>%;"></div>
</div>