<li class="parent {li_class}"><a href="{parent_href}" class="{link_class}">{title}</a><ul class="{ul_class}">
{subnav}
</ul></li>