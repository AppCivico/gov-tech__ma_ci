<div class="field-no-results">
	<p>
		<?=lang($text)?>
		<?php if (isset($link_href)): ?>
			<a href="<?=$link_href?>" rel="add_new">
				<?=lang($link_text)?>
			</a>
		<?php endif ?>
	</p>
</div>
