<div class="app-modal app-modal--center" rel="modal-bulk-edit">
	<div class="app-modal__content">
		<div class="app-modal__dismiss">
			<a class="js-modal-close" rel="modal-bulk-edit" href="#"><?=lang('close_modal')?></a> <span class="txt-fade">[esc]</span>
		</div>
		<div class="col-group align-right">
			<div class="col w-12 remove-pad--right">
				Form
			</div>
			<div class="col w-4 remove-pad--left" data-bulk-edit-entries-react>
				<!-- filter -->
			</div>
		</div>
	</div>
</div>
