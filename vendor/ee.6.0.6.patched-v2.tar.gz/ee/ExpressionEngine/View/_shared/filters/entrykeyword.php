        <input class="search-input__input input--small input-clear" type="text" name="<?=$name?>" value="<?=$value?>" placeholder="<?=$placeholder?>" autofocus>
        <i class="fas fa-search icon-start icon--small"></i>
