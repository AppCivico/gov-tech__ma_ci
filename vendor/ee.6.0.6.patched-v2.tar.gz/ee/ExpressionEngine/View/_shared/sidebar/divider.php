<div class="sidebar__section-divider"></div>
