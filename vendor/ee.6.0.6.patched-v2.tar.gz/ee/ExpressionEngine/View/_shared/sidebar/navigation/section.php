<div class="ee-sidebar__items-<?=$class_suffix?>">
    <?php if (!empty($header)) : ?>
    <span class="ee-sidebar__section-label"><?=$header?></span>
    <?php endif; ?>
    <?=$items?>
</div>
