<div class="box sidebar <?=$class?>">
	<?=$sidebar?>
</div>
