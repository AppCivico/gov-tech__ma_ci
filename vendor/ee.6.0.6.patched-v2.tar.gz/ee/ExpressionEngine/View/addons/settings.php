<?php $this->extend('_templates/default-nav', [], 'outer_box'); ?>


	<?=$_module_cp_body?>
