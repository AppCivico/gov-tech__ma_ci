<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Toggle',
    'description' => 'On/Off Toggle Switch',
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\ToggleField',
    'settings_exist' => false,
    'built_in' => true,
);
