<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Email',
    'description' => 'Create contact and tell-a-friend forms',
    'version' => '2.1.0',
    'namespace' => 'ExpressionEngine\Addons\Email',
    'settings_exist' => false,
);
