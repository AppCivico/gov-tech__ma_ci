<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'XML Encode',
    'description' => 'XML Encoding plugin',
    'version' => '2.0.0',
    'namespace' => 'ExpressionEngine\Addons\XmlEncode',
    'settings_exist' => false,
    'plugin.typography' => true
);

// EOF
