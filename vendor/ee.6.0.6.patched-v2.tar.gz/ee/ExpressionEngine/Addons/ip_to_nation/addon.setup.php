<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'IP to Nation',
    'description' => 'Determine which country an IP address is associated with',
    'version' => '3.0.0',
    'namespace' => 'ExpressionEngine\Addons\IpToNation',
    'settings_exist' => true,
);
