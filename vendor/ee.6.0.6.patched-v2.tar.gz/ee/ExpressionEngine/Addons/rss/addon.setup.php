<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Rss',
    'description' => 'Create RSS feeds',
    'version' => '2.0.0',
    'namespace' => 'ExpressionEngine\Addons\Rss',
    'settings_exist' => false,
);
