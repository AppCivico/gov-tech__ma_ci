<?php

return [
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Request',
    'description' => 'Use HTTP request variables in your templates',
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\Request',
    'settings_exist' => false,
    'built_in' => false,
];
