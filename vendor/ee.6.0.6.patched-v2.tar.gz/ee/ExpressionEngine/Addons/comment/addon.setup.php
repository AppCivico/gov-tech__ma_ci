<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Comment',
    'description' => '',
    'version' => '2.3.3',
    'namespace' => 'ExpressionEngine\Addons\Comment',
    'settings_exist' => false,
    'built_in' => true,
);
