<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Query',
    'description' => 'Perform SQL queries without PHP',
    'version' => '2.0.0',
    'namespace' => 'ExpressionEngine\Addons\Query',
    'settings_exist' => false,
);
