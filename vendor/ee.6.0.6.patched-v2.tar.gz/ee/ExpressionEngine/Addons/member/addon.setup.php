<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Member',
    'description' => '',
    'version' => '2.2.1',
    'namespace' => 'ExpressionEngine\Addons\Member',
    'settings_exist' => false,
    'built_in' => true
);
