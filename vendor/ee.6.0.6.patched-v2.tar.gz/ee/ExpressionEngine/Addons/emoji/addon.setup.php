<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Emoji',
    'description' => 'Parse and display emoji',
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\Emoji',
    'settings_exist' => false,
);
