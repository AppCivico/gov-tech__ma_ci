<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Checkboxes',
    'description' => '',
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\Checkboxes',
    'settings_exist' => false,
    'built_in' => true,
    'fieldtypes' => array(
        'checkboxes' => array(
            'compatibility' => 'list'
        )
    )
);
