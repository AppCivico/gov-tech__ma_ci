<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Search',
    'description' => '',
    'version' => '2.2.2',
    'namespace' => 'ExpressionEngine\Addons\Search',
    'settings_exist' => false,
    'built_in' => true
);
