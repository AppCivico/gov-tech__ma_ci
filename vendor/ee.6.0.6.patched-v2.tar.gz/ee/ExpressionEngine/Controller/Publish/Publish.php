<?php
/**
 * This source file is part of the open source project
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2021, Packet Tide, LLC (https://www.packettide.com)
 * @license   https://expressionengine.com/license Licensed under Apache License, Version 2.0
 */

namespace ExpressionEngine\Controller\Publish;

use ExpressionEngine\Controller\Publish\AbstractPublish as AbstractPublishController;
use ExpressionEngine\Service\Validation\Result as ValidationResult;
use ExpressionEngine\Model\Channel\ChannelEntry;

/**
 * Publish Controller
 */
class Publish extends AbstractPublishController
{
    public function __construct()
    {
        parent::__construct();

        $perms = [];

        foreach ($this->assigned_channel_ids as $channel_id) {
            $perms[] = 'can_create_entries_channel_id_' . $channel_id;
            $perms[] = 'can_edit_self_entries_channel_id_' . $channel_id;
            $perms[] = 'can_edit_other_entries_channel_id_' . $channel_id;
        }

        if (! ee('Permission')->hasAny($perms)) {
            show_error(lang('unauthorized_access'), 403);
        }
    }

    /**
     * Renders a single field for a given channel or channel entry
     *
     * @param int $channel_id The Channel ID
     * @param int $entry_id The Entry ID
     * @return array An associative array (for JSON) containing the rendered HTML
     */
    public function field($channel_id, $entry_id)
    {
        if (is_numeric($entry_id) && $entry_id != 0) {
            $entry = ee('Model')->get('ChannelEntry', $entry_id)
                ->filter('site_id', ee()->config->item('site_id'))
                ->first();
        } else {
            $entry = ee('Model')->make('ChannelEntry');
            $entry->Channel = ee('Model')->get('Channel', $channel_id)->first();
        }

        $entry->set($_POST);

        return array('html' => $entry->getCustomField(ee()->input->get('field_name'))->getForm());
    }

    /**
     * Populates the default author list in Channel Settings, also serves as
     * AJAX endpoint for that filtering
     *
     * @return array ID => Screen name array of authors
     */
    public function authorList()
    {
        $authors = ee('Member')->getAuthors(ee('Request')->get('search'));

        if (AJAX_REQUEST) {
            return ee('View/Helpers')->normalizedChoices($authors);
        }

        return $authors;
    }

    /**
     * AJAX end-point for relationship field filtering
     */
    public function relationshipFilter()
    {
        ee()->load->add_package_path(PATH_ADDONS . 'relationship');
        ee()->load->library('EntryList');
        ee()->output->send_ajax_response(ee()->entrylist->ajaxFilter());
    }

    /**
     * Autosaves a channel entry
     *
     * @param int $channel_id The Channel ID
     * @param int $entry_id The Entry ID
     * @return void
     */
    public function autosave($channel_id, $entry_id)
    {
        $site_id = ee()->config->item('site_id');

        $autosave = ee('Model')->get('ChannelEntryAutosave')
            ->filter('original_entry_id', $entry_id)
            ->filter('site_id', $site_id)
            ->filter('channel_id', $channel_id)
            ->first();

        if (! $autosave) {
            $autosave = ee('Model')->make('ChannelEntryAutosave');
            $autosave->original_entry_id = $entry_id;
            $autosave->site_id = $site_id;
            $autosave->channel_id = $channel_id;
        }

        $autosave->edit_date = ee()->localize->now;
        $autosave->entry_data = $_POST;

        // This is currently unused, but might be useful for display purposes
        $autosave->author_id = ee()->input->post('author_id', ee()->session->userdata('member_id'));

        // This group of columns is unused
        $autosave->title = (ee()->input->post('title')) ?: 'autosave_' . ee()->localize->now;
        $autosave->url_title = (ee()->input->post('url_title')) ?: 'autosave_' . ee()->localize->now;
        $autosave->status = ee()->input->post('status');

        // This group of columns is also unused
        $autosave->entry_date = 0;
        $autosave->year = 0;
        $autosave->month = 0;
        $autosave->day = 0;

        $autosave->save();

        $time = ee()->localize->human_time(ee()->localize->now);
        $time = trim(strstr($time, ' '));

        ee()->output->send_ajax_response(array(
            'success' => ee('View')->make('ee:publish/partials/autosave_badge')->render(['time' => $time]),
            'autosave_entry_id' => $autosave->entry_id,
            'original_entry_id' => $entry_id
        ));
    }

    /**
     * Creates a new channel entry
     *
     * @param int $channel_id The Channel ID
     * @param int|NULL $autosave_id An optional autosave ID, for pre-populating
     *   the form
     * @return string Rendered HTML
     */
    public function create($channel_id = null, $autosave_id = null)
    {
        if (! $channel_id) {
            show_404();
        }

        if (! ee('Permission')->can('create_entries_channel_id_' . $channel_id) or
             ! in_array($channel_id, $this->assigned_channel_ids)) {
            show_error(lang('unauthorized_access'), 403);
        }

        $channel = ee('Model')->get('Channel', $channel_id)
            ->filter('site_id', ee()->config->item('site_id'))
            ->first();

        if (! $channel) {
            show_error(lang('no_channel_exists'));
        }

        // Redirect to edit listing if we've reached max entries for this channel
        if ($channel->maxEntriesLimitReached()) {
            ee()->functions->redirect(
                ee('CP/URL')->make('publish/edit/', array('filter_by_channel' => $channel_id))
            );
        }

        $entry = ee('Model')->make('ChannelEntry');
        $entry->Channel = $channel;
        $entry->site_id = ee()->config->item('site_id');
        $entry->author_id = ee()->session->userdata('member_id');
        $entry->ip_address = ee()->session->userdata['ip_address'];
        $entry->versioning_enabled = $channel->enable_versioning;
        $entry->sticky = false;

        // Set some defaults based on Channel Settings
        $entry->allow_comments = (isset($channel->deft_comments)) ? $channel->deft_comments : true;

        if (isset($channel->deft_status)) {
            $entry->status = $channel->deft_status;
        }

        if (! empty($channel->deft_category)) {
            $cat = ee('Model')->get('Category', $channel->deft_category)->first();
            if ($cat) {
                // set directly so other categories don't get lazy loaded
                // along with our default
                $entry->Categories = $cat;
            }
        }

        $entry->title = $channel->default_entry_title;
        $entry->url_title = $channel->url_title_prefix;

        if (isset($_GET['BK'])) {
            $this->populateFromBookmarklet($entry);
        }

        ee()->view->cp_page_title = sprintf(lang('create_entry_with_channel_name'), $channel->channel_title);

        $form_attributes = array(
            'class' => 'ajax-validate',
        );

        $vars = array(
            'form_url' => ee('CP/URL')->getCurrentUrl(),
            'form_attributes' => $form_attributes,
            'form_title' => lang('new_entry'),
            'errors' => new \ExpressionEngine\Service\Validation\Result(),
            'revisions' => $this->getRevisionsTable($entry),
            'buttons' => $this->getPublishFormButtons($entry),
            'header' => [
                'title' => lang('new_entry'),
            ],
        );

        if (ee('Request')->get('modal_form') == 'y') {
            $vars['buttons'] = [[
                'name' => 'submit',
                'type' => 'submit',
                'value' => 'save_and_close',
                'text' => 'save_and_close',
                'working' => 'btn_saving'
            ]];
        }

        if ($entry->isLivePreviewable()) {
            $lp_domain_mismatch = false;
            $configured_site_url = explode('//', ee()->config->item('site_url'));
            $configured_domain = explode('/', $configured_site_url[1]);

            if ($_SERVER['HTTP_HOST'] != strtolower($configured_domain[0])) {
                $lp_domain_mismatch = true;
                $lp_message = sprintf(lang('preview_domain_mismatch_desc'), $configured_domain[0], $_SERVER['HTTP_HOST']);
            } elseif ($configured_site_url[0] != '' && ((ee('Request')->isEncrypted() && strtolower($configured_site_url[0]) != 'https:') || (!ee('Request')->isEncrypted() && strtolower($configured_site_url[0]) == 'https:'))) {
                $lp_domain_mismatch = true;
                $lp_message = sprintf(lang('preview_protocol_mismatch_desc'), $configured_site_url[0], (ee('Request')->isEncrypted() ? 'https' : 'http'));
            }

            if ($lp_domain_mismatch) {
                $lp_setup_alert = ee('CP/Alert')->makeBanner('live-preview-setup')
                    ->asIssue()
                    ->canClose()
                    ->withTitle(lang('preview_cannot_display'))
                    ->addToBody($lp_message);
                ee()->javascript->set_global('alert.lp_setup', $lp_setup_alert->render());
            } else {
                $action_id = ee()->db->select('action_id')
                    ->where('class', 'Channel')
                    ->where('method', 'live_preview')
                    ->get('actions');
                $modal = ee('View')->make('publish/live-preview-modal')->render([
                    'preview_url' => ee()->functions->fetch_site_index() . QUERY_MARKER . 'ACT=' . $action_id->row('action_id') . AMP . 'channel_id=' . $entry->channel_id
                ]);
                ee('CP/Modal')->addModal('live-preview', $modal);
            }
        } elseif (ee('Permission')->hasAll('can_admin_channels', 'can_edit_channels')) {
            $lp_setup_alert = ee('CP/Alert')->makeBanner('live-preview-setup')
                ->asIssue()
                ->canClose()
                ->withTitle(lang('preview_url_not_set'))
                ->addToBody(sprintf(lang('preview_url_not_set_desc'), ee('CP/URL')->make('channels/edit/' . $entry->channel_id)->compile() . '#tab=t-4&id=fieldset-preview_url'));
            ee()->javascript->set_global('alert.lp_setup', $lp_setup_alert->render());
        }

        if ($autosave_id) {
            $autosaved = ee('Model')->get('ChannelEntryAutosave', $autosave_id)
                ->filter('channel_id', $channel_id)
                ->filter('site_id', ee()->config->item('site_id'))
                ->first();

            if ($autosaved) {
                $entry->set($autosaved->entry_data);
            }
        }

        $channel_layout = ee('Model')->get('ChannelLayout')
            ->filter('site_id', ee()->config->item('site_id'))
            ->filter('channel_id', $entry->channel_id)
            ->with('PrimaryRoles')
            ->filter('PrimaryRoles.role_id', ee()->session->userdata('role_id'))
            ->first();

        $vars['layout'] = $entry->getDisplay($channel_layout);

        $result = $this->validateEntry($entry, $vars['layout']);

        if ($result instanceof ValidationResult) {
            $vars['errors'] = $result;

            if ($result->isValid()) {
                return $this->saveEntryAndRedirect($entry);
            }
        }

        // Auto-saving needs an entry_id...
        $entry->entry_id = 0;

        $vars['autosaves'] = $this->getAutosavesTable($entry, $autosave_id);
        $vars['entry'] = $entry;

        $this->setGlobalJs($entry, true);

        ee()->cp->add_js_script(array(
            'plugin' => array(
                'ee_url_title',
                'ee_filebrowser',
                'ee_fileuploader',
            ),
            'ui' => ['draggable'],
            'file' => array('cp/publish/publish', 'cp/channel/category_edit')
        ));

        ee()->view->cp_breadcrumbs = array(
            ee('CP/URL')->make('publish/edit')->compile() => lang('entries'),
            '' => lang('new_entry')
        );

        $vars['breadcrumb_title'] = lang('new_entry');

        if (ee('Request')->get('modal_form') == 'y') {
            $vars['layout']->setIsInModalContext(true);

            return ee('View')->make('publish/modal-entry')->render($vars);
        }

        ee()->cp->render('publish/entry', $vars);
    }

    /**
     * Populates a channel entry entity from a bookmarklet action
     *
     * @param ChannelEntry $entry A Channel Entry entity to populate
     * @return void
     */
    private function populateFromBookmarklet(ChannelEntry $entry)
    {
        $data = array();

        if (($title = ee()->input->get('title')) !== false) {
            $data['title'] = $title;
        }

        foreach ($_GET as $key => $value) {
            if (strpos($key, 'field_id_') === 0) {
                $data[$key] = $value;
            }
        }

        if (empty($data)) {
            return;
        }

        $entry->set($data);
    }

    public function preview($channel_id, $entry_id = null)
    {
        return ee('LivePreview')->preview($channel_id, $entry_id);
    }
}

// EOF
