<?php

$this->extend('ee:_shared/iframe-modal');

$this->embed('ee:publish/partials/publish_form');
