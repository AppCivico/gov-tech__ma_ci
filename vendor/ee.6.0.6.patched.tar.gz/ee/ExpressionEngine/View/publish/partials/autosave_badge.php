<span class="app-badge app-badge---important"><b><?=lang('autosave_success')?></b> (<?=$time?>)</span>
