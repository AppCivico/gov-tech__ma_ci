<a class="sidebar__link <?=$class?>" href="<?=$url?>" <?=$attrs?>>
<?php if (!empty($icon)): ?><i class="fas fa-<?=$icon?> fa-fw"></i><?php endif; ?>
 <?=$text?>
</a>
