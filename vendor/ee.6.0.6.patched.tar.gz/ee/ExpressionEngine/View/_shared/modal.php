<div class="modal-wrap <?=$name?> hidden">
	<div class="modal">
		<div class="col-group">
			<div class="col w-16">
				<a class="m-close" href="#"></a>
				<div class="box">
					<?=$contents?>
				</div>
			</div>
		</div>
	</div>
</div>