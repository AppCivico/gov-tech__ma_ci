<div class="filter-search-bar__item">
	<div class="search-input">
		<input class="search-input__input input--small" type="text" name="<?=$name?>" value="<?=$value?>" placeholder="<?=$placeholder?>">
	</div>
</div>
